KansakuTUT 1.001
漢索フォント for TUT-Code
http://nixeneko.hatenablog.com/entry/2015/12/24/031005

橋田表という打鍵図をフォントで再現しようとしたものです。

内容物
======
kansakutut.otf:	フォントファイル本体
webfont/:	Fontie https://fontie.flowyapps.com/ を利用してWebフォントに変換したもの
src/:	フォント生成に使ったファイル郡
src/base/*.svg:	フォントで使うための図形
src/convert.py:	tutcode.mim_edited を読み込み、　setglyph.pe (Fontforgeスクリプト)を出力する
src/tutcode.mim_edited:	m17n libraryを使用してTUT-Codeが入力できるようにするためのファイルを編集したもの
			cf. http://www1.interq.or.jp/~deton/tutcode/
src/glyphbase.sfd:	組み合わせ用の図形をグリフとして準備したフォントのFontforgeファイル
src/kansaku.nam:	組み合わせに使うための図形のグリフに名前をつけるための対応表。 glyphbase.sfd に適用済み


フォント生成方法
================
1. convert.py を実行する
$ python convert.py
すると　setglyph.pe ができあがる

2. Fontforge で setglyph.pe を実行する
Windows の人はスタートメニューから FontForge interactive console を開き、
fontforge -script setglyph.pe
などを実行する。すると kansakutut.sfd が出来上がる。

3. kansakutut.sfd を Fontforge で開き、（必要あれば微調整し）フォントとして出力する。
なぜか平仮名の「へ」がうまく表示されなかったので手動で設定しています。


﻿# coding: utf-8

import codecs, re
import copy

strokelist = 'tutcode.mim_edited'
p = re.compile(r'\("(.+)" "(.*)"\)')

template = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 0, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 0, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0]
key = {
    '!':  0, '"':  1, '#':  2, '$':  3, '%':  4, '&':  5, "'":  6, '(':  7, ')':  8, 
    '1':  0, '2':  1, '3':  2, '4':  3, '5':  4, '6':  5, '7':  6, '8':  7, '9':  8, '0':  9,
    'Q': 10, 'W': 11, 'E': 12, 'R': 13, 'T': 14, 'Y': 15, 'U': 16, 'I': 17, 'O': 18, 'P': 19,
    'q': 10, 'w': 11, 'e': 12, 'r': 13, 't': 14, 'y': 15, 'u': 16, 'i': 17, 'o': 18, 'p': 19,
    'A': 20, 'S': 21, 'D': 22, 'F': 23, 'G': 24, 'H': 25, 'J': 26, 'K': 27, 'L': 28, '+': 29,
    'a': 20, 's': 21, 'd': 22, 'f': 23, 'g': 24, 'h': 25, 'j': 26, 'k': 27, 'l': 28, ';': 29,
    'Z': 30, 'X': 31, 'C': 32, 'V': 33, 'B': 34, 'N': 35, 'M': 36, '<': 37, '>': 38, '?': 39,
    'z': 30, 'x': 31, 'c': 32, 'v': 33, 'b': 34, 'n': 35, 'm': 36, ',': 37, '.': 38, '/': 39, 
    ' ': 40}
    
charset = set()
chars = {}
with codecs.open(strokelist, 'r', 'utf-8') as f:
    for line in f:
        m = p.match(line.strip())
        if m:
            stroke, char = m.group(1), m.group(2)
            chars[ord(char)] = stroke
            #s = map(lambda c: nameconv[c], list(stroke))
            #print(' '.join(s))
            charset |= set(stroke)
            charset |= set(char)

tutlist={}
for char, strokes in sorted(chars.items()):
    table = copy.copy(template)
    for (i, s) in enumerate(strokes):
        table[key[s]] = 2**(i+1)
    
    glflst = ['blanc']
    for n in range(40):
        v = table[n]
        nameprfx = ''
        if v:
            if v == 1:
                nameprfx = 'dot'
            elif v == 2 or v == 3:
                nameprfx = 'bcirc'
            elif v == 4 or v == 5:
                nameprfx = 'wcirc'
            elif v == 8 or v == 9:
                nameprfx = 'tri'
            elif v == 16 or v == 17:
                nameprfx = 'dia'
            else:
                nameprfx = 'cirincir'
            glflst.append('{}{:02}'.format(nameprfx, n))
            
    tutlist[char] = glflst
    #↓は動かない、だめ
    #print('  substitute uni{:0>4X} by blanc {} ;'.format(char, ' '.join(glflst)) )
    
    #参照をコピー→貼り付けを繰り返すことにしよう……
    #CopyReference()
    #PasteInto()

with codecs.open('setglyph.pe', 'w', 'utf-8') as f:
    f.write('Open("glyphbase.sfd")\n')
    #f.write('Select(0u20, 0u7e)\n') #ascii
    for char, glyphs in sorted(tutlist.items()):
        f.write('Select(0u{:X})\n'.format(char))
        f.write('SetWidth(2000)\n')
        for gname in glyphs:
            f.write('Select("{}")\n'.format(gname))
            f.write('CopyReference()\n')
            f.write('Select(0u{:X})\n'.format(char))
            f.write('PasteInto()\n')
        
    #f.write('SetWidth(1000)\n')
    f.write('Save("kansakutut.sfd")\n')
    